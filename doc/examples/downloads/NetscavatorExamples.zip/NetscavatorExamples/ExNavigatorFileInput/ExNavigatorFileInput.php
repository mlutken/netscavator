<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName               () { return "ExNavigatorFileInput"; }
function ExNavigatorFileInput_urlSite   () { return "examples.netscavator.com/sites/ExNavigatorFileInput/index.php";       }
function ExNavigatorFileInput_urlStart  () { return "examples.netscavator.com/sites/ExNavigatorFileInput/dosearch.php";    }

function ExNavigatorFileInput_beginMining()         
{
    // Define dom sequences for the positions we need
    domSeqCreate  ( "DoSearchBtnSeq"    , "INPUT, value, Search"        , "equals"          );
    domSeqCreate  ( "ProductStartSeq"   , "DIV, class, product"         , "equals"          );
    domSeqCreate  ( "ProductNameSeq"    , "color:green"                 , "contains", 1     );
    domSeqCreate  ( "FabricTypeSeq"     , "color:black"                 , "contains", 1     );
    domSeqCreate  ( "ProductPriceSeq"   , "EUR"                         , "contains"        );
    
    domSeqCreate  ( "DoClickNextSeq"    , "Next, /A"                    , "contains", -2    );
    // (NOTE: we step back so we are sure to be within the A tag when we 'click' on the link.)

    domSeqCreate  ( "ClothesSelectSeq"  , "INPUT, name, clothes_type"  , "equals"          );
    
    // Navigator
    navInputOptionsCreate( "clothesSelect" );
    navOptionResourceAdd( "http://examples.netscavator.com/sites/ExNavigatorFileInput/clothes_types.txt", "", true );
    //navOptionResourceAdd( "http://examples.netscavator.com/sites/ExNavigatorFileInput/clothes_types.txt.gz", "", true );
    // NOTE: You need to prepend 'http://' if your resource file is somewhere 'online'. If you don't
    //       the miner assumes the file is on the local filesystem. This will be fixed in a 
    //       future release so that if the path without 'http://' is not found on the local filesystem 
    //       then we try again online with 'http://' prepended.
}

function filterFabricType($val)
{
    $val = eraseAll_fn($val, "(" );
    $val = eraseAll_fn($val, ")" );
    return $val;
}


// -------------------------------
// --- DoSearch page functions ---
// -------------------------------
function ExNavigatorFileInput_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function ExNavigatorFileInput_DoSearch_mine()            
{
    // Nothing to mine on the "do search" page
}


function ExNavigatorFileInput_DoSearch_navigate()           
{   
    doActionFind ( 1, "ClothesSelectSeq",   "clothesSelect" ); // Select clothes drop down according to current navigator state
    doActionFind ( 1, "DoSearchBtnSeq",     "click" );         // Click on search button.
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// --------------------------------
// --- Search listing functions ---
// --------------------------------
function ExNavigatorFileInput_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function ExNavigatorFileInput_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStartSeq" );
        domSetStopPos( $iStopPos );
        GetProduct();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct()            
{
    // Get product name and  product price
    contextBegin("product");
    outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPriceSeq", "product_price", "trimNumber" );
    outputValueFindNext( 1, "FabricTypeSeq", "fabric", "filterFabricType" );
    outputValueFindNext( 1, "", "sex" );   // Oups: This fails, but see ExNavigatorFileInputFilter example for a solution
    outputDirect ( "currency_name" , "EUR" );  
    outputDirect ( "navigator_state", navStateString() );   // Write the navigator state for demo/debug
    contextEnd();
}

function ExNavigatorFileInput_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNextSeq" ) ) {
        nodeClick();
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad ( "examples.netscavator.com/sites/ExNavigatorFileInput/dosearch.php" );  // Back to search page
            return true;
        }
        return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}

?>

