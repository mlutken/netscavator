<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName                       () {   return "ExDoSearchActionsAndClickNext";       }

function ExDoSearchActionsAndClickNext_urlSite  () {   return "examples.netscavator.com/sites/ExDoSearchActionsAndClickNext/index.php";       }
function ExDoSearchActionsAndClickNext_urlStart () {   return "examples.netscavator.com/sites/ExDoSearchActionsAndClickNext/dosearch.php";    }

function ExDoSearchActionsAndClickNext_beginMining()         
{
    // Define dom sequences for the positions we need
    domSeqCreate  ( "DoSearchTypeSeq"   , "INPUT, name, producttype", "equals"          );
    domSeqCreate  ( "DoSearchBtnSeq"    , "INPUT, value, Search"    , "equals"          );
    domSeqCreate  ( "ProductStartSeq"   , "DIV, class, product"     , "equals"          );
    domSeqCreate  ( "ProductNameSeq"    , "color:green"             , "contains", 1     );
    domSeqCreate  ( "ProductPriceSeq"   , "EUR"                     , "contains"        );
    
    domSeqCreate  ( "DoClickNextSeq"    , "Next, /A"                , "contains", -2    );
    // (NOTE: we step back so we are sure to be within the A tag when we 'click' on the link.)
}


// -------------------------------
// --- DoSearch page functions ---
// -------------------------------
function ExDoSearchActionsAndClickNext_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function ExDoSearchActionsAndClickNext_DoSearch_mine()            
{
    // Nothing to mine on the "do search" page
}


function ExDoSearchActionsAndClickNext_DoSearch_navigate()           
{   
    doActionFind ( 1, "DoSearchTypeSeq", "inputValue", "all" ); // Type 'all' (action = 'inputValue') in producttype field.
    doActionFind ( 1, "DoSearchBtnSeq", "click" );              // Click on search button.
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// --------------------------------
// --- Search listing functions ---
// --------------------------------
function ExDoSearchActionsAndClickNext_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function ExDoSearchActionsAndClickNext_SearchListing_mine()            
{
    printf("SearchListing_mine\n");
    domNewSearch();
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStartSeq" );
        domSetStopPos( $iStopPos );
        GetProduct();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct()            
{
    // Get product name and  product price
    contextBegin("product");
    outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPriceSeq", "product_price", "trimNumber" );
    outputDirect ( "currency_name" , "EUR" );  
    contextEnd();
}

function ExDoSearchActionsAndClickNext_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNextSeq" ) ) {
        nodeClick();
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else {
        return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}

?>

