#!/bin/bash
# Set examples here to use localhost

./subst.pl examples.netscavator.com sleipnerexamples.com.localhost \*.php .


