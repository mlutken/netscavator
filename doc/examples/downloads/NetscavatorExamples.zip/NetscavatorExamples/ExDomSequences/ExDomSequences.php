<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName       () {   return "ExDomSequences";       }

function ExDomSequences_urlSite () {   return "examples.netscavator.com/sites/ExDomSequences";   }

function ExDomSequences_beginMining()         
{
    // Define dom sequences for the positions we need
    domSeqCreate  ( "ProductStartSeq"   , "DIV, class, product" , "equals"      );
    domSeqCreate  ( "ProductNameSeq"    , "color:green"         , "contains", 1 );
    domSeqCreate  ( "ProductPriceSeq"   , "EUR"                 , "contains"    );
}

// --------------------------------
// --- Search listing functions ---
// --------------------------------
function ExDomSequences_SearchListing_match()          
{   
    return true;   
}

function ExDomSequences_SearchListing_mine()            
{
    domNewSearch();
    
    // Loop through all products listed, by finding the start of next product
    // and from there find the name and the price
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        contextBegin("product");
        domFindNext ( 1, "ProductNameSeq" );
        outputValue ( "product_name" );
        
        domFindNext ( 1, "ProductPriceSeq" );
        outputValue ( "product_price" );
        contextEnd();
    }
}

function ExDomSequences_SearchListing_navigate()           
{   
    return false;    
}

?>

