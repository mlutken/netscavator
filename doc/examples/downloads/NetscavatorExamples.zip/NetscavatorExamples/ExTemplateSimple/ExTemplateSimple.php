<?php
require_once "ExTemplateSimple.tpl.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName           () {   return "ExTemplateSimple";       }
function ExTemplateSimple_urlSite   () {   return "examples.netscavator.com/sites/ExTemplateSimple";   }

function ExTemplateSimple_beginMining()         
{
    // Define dom sequences for the positions we need
    domSeqCreate  ( "ProductStartSeq"   	, "DIV, class, product" , "equals"      );
    domSeqCreate  ( "ProductNameSeq"	    , "color:green"         , "contains", 1 );
    domSeqCreate  ( "ProductPriceSeq"   	, "EUR"                 , "contains"    );
}

// -----------------------
// --- Match functions ---
// -----------------------
function ExTemplateSimple_SearchListing_match()          
{   
    return true;  // When we only mine a single page simply say that any page is the correct one.
}

?>

