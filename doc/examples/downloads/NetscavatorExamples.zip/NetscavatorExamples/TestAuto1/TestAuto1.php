<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------


function Script_minerName    () {   return "TestAuto1";       }
function TestAuto1_urlSite   () {   return "examples.netscavator.com/sites/TestAuto1/";       }
function TestAuto1_urlStart  () {   return "examples.netscavator.com/sites/TestAuto1/dosearch.php";    }

function TestAuto1_beginMining()         
{
//    browserSetSize(100,100);
    // --- Dom sequences for the DoSearch (DS) page ---
    domSeqCreate  ( "DoSearchBtn_FIND_DS"    , "INPUT, value, Search"        , "equals"          );
    domSeqCreate  ( "ClothesSelect_FIND_DS"  , "SELECT, name, clothes_type"  , "equals"          );
    domSeqCreate  ( "FabricSelect_FIND_DS"   , "SELECT, name, fabric_type"   , "equals"          );

    // --- Dom sequences for the SearchListing (SL) page ---
    domSeqCreate  ( "ProductStart_FIND_SL"   , "DIV, class, product"         , "equals"          );
    domSeqCreate  ( "ProductUrl_FIND_SL"     , "A, href, productPage.php"    , "contains"        );
    domSeqCreate  ( "DoClickNext_FIND_SL"    , "Next, /A"                    , "contains", -2    );

    // --- Dom sequences for the ProductPage (PP) page ---
    domSeqCreate  ( "ProductName_FIND_PP"    , "TD, Type:, /TD, TD"           , "contains", 1   );  
    domSeqCreate  ( "ProductPrice_FIND_PP"   , "TD, Price:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductColor_FIND_PP"   , "TD, Color:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductFabric_FIND_PP"  , "TD, Fabric, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductBrand_FIND_PP"   , "TD, Brand:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductId_FIND_PP"      , "TD, Product ID:, /TD, TD"     , "contains", 1   );  
    domSeqCreate  ( "ProductSex_FIND_PP"     , ""                             , "contains", 0  );  

    
    
    
    // Navigator
    navDropDownSelectCreate("clothesSelect");
    navAttributeNamesCreate ("product_name, sex");
    navOptionAdd ( 1,  "dresses"        , ATTR, "Dress,  F"  );
    navOptionAdd ( 2,  "ties"           , ATTR, "Tie,    M"  );
    navOptionAdd ( 3,  "jackets"        , ATTR, "Jacket, MF" );
    navDropDownSelectCreate("fabricSelect");
    navAttributeNamesCreate ("fabric");
    navOptionAdd ( 1,  "wool"           , ATTR, "Wool"       );
    navOptionAdd ( 2,  "cotton"         , ATTR, "Cotton"     );

    navStart(); // Important: Start navigator 

    //dbgPrintNavigatorStates(10); // Comment in to print the states. Parameter is specifying how many states to print at most. 

}


// ------------------------------------
// --- DoSearch (DS) page functions ---
// ------------------------------------
function TestAuto1_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function TestAuto1_DoSearch_mine()            
{
    // Nothing to mine on the "do search" page
    
    
}


function TestAuto1_DoSearch_navigate()           
{   
    doActionFind ( 1, "ClothesSelect_FIND_DS",   "clothesSelect" ); // Select clothes drop down according to current navigator state
    doActionFind ( 1, "FabricSelect_FIND_DS",    "fabricSelect"  ); // Select fabric drop down according to current navigator state
    doActionFind ( 1, "DoSearchBtn_FIND_DS",     "click" );         // Click on search button.


    contextBegin("DoSearch_Test_2");
    domFind( 1, "ClothesSelect_FIND_DS" );
    outputDirect ("dompos" , "" . domGetPos() );
    outputDirect ("selectLength" , "" . selectLength() );
    outputDirect ("selectSelectedIndex" , "" . selectSelectedIndex() );
    outputDirect ("selectSelectedDomPos" , "" . selectSelectedDomPos() );
    
    
    contextEnd();
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// -------------------------------------
// --- Search listing (SL) functions ---
// -------------------------------------
function TestAuto1_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function TestAuto1_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStart_FIND_SL" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStart_FIND_SL" );
        domSetStopPos( $iStopPos );
        GetProduct_SL();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct_SL()            
{
    //printf("trimNumber_fn('  25.45  '): '%s'\n", trimNumber_fn('  25.45  ') );
    // All we need to do here is to put the (full) URL of each element in the urlQueue.
    // Since each URL is only relative to the current site we prepend urlSite()
    if ( domFindNext ( 1, "ProductUrl_FIND_SL" ) ) {
        urlQueueAppendUnique( urlSite() . valueGet() );
        //printf("DBG: urlSite() . valueGet(): %s\n", urlSite() . valueGet()  );
    }
}

function TestAuto1_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNext_FIND_SL" ) ) {
        nodeClick();
        //nodeClick(NEAREST_AUTO, false);
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else if ( urlQueueSize() > 0 ) {
        return false;       // Start to emty the queue
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad ( "examples.netscavator.com/sites/TestAuto1/dosearch.php" );  // Back to search page
            return true;
        }
        //return true;    // Enable this to prevent miner from closing down after scanning.
        return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}



// ----------------------------------
// --- ProductPage (PP) functions ---
// ----------------------------------
function TestAuto1_ProductPage_match()          
{   
    return contains_fn( urlCurrent() , "productPage.php" );  // Handle any page with 'productPage.php' in the URL.
}

function TestAuto1_ProductPage_mine()            
{
    domNewSearch();
    // Get product name and  product price
    contextBegin("product");
    
    domPointerPush();
    if ( domFindNext( 1, "ProductName_FIND_PP" ) ) {
        outputDirect ( "PRODUCT_NAME_DOM_POS", "" . domGetPos()   );
        outputDirect ( "PRODUCT_NAME_NODE_VAL", nodeValue()   );
        outputDirect ( "PRODUCT_NAME_PARENT_DOM_POS", "" . domFindParentPos(1)   );
        outputDirect ( "PRODUCT_NAME_PARENT_NODE_VAL", nodeValueParent(1)    );
        outputDirect ( "PRODUCT_NAME_PARENT2_DOM_POS", "" . domFindParentPos(2)   );
        outputDirect ( "PRODUCT_NAME_PARENT2_NODE_VAL", nodeValueParent(2)    );
        outputDirect ( "PRODUCT_NAME_PARENT3_DOM_POS", "" . domFindParentPos(3)   );
        outputDirect ( "PRODUCT_NAME_PARENT3_NODE_VAL", nodeValueParent(3)    );
        outputDirect ( "PRODUCT_NAME_PARENT4_DOM_POS", "" . domFindParentPos(4)   );
        outputDirect ( "PRODUCT_NAME_PARENT4_NODE_VAL", nodeValueParent(4)    );
        outputDirect ( "PRODUCT_NAME_PARENT5_DOM_POS", "" . domFindParentPos(5)   );
        outputDirect ( "PRODUCT_NAME_PARENT5_NODE_VAL", nodeValueParent(5)    );
    }
    domPointerPop();
    // --------------------
    
    
    outputDirect( "product_url" , urlCurrent() );
    outputValueFindNext( 1, "ProductName_FIND_PP"   , "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPrice_FIND_PP"  , "product_price", "trimNumber" );
    outputValueFindNext( 1, "ProductColor_FIND_PP"  , "color"  );
    outputValueFindNext( 1, "ProductFabric_FIND_PP" , "fabric" );  
    outputValueFindNext( 1, "ProductBrand_FIND_PP"  , "brand_name" );  
    outputValueFindNext( 1, "ProductId_FIND_PP"     , "product_id" );  
    outputValueFindNext( 1, "ProductSex_FIND_PP"    , "sex" );   // Get value from Navigator attribute by fallback on fail to find dom pos
    outputDirect ( "currency_name" , "EUR" );  
    outputDirect ( "navigator_state", navStateString() );   // Write the navigator state for demo/debug
    contextEnd();
}


function TestAuto1_ProductPage_navigate()           
{   
    if ( urlQueueSize() > 0 ) {
        return false;   // Process next ProductPage in queue
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad ( "examples.netscavator.com/sites/TestAuto1/dosearch.php" );  // Back to search page
            return true;
        }
    }
    return false;
}



// --------------
// --- Do run ---
// --------------

//dbgSimpleTestFunction();
initMining();
addMiner( "TestAuto1" );
runMiners();

?>

