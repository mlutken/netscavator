<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName               () {   return "ExProductPageMining";       }
function ExProductPageMining_urlSite   	() {   return "examples.netscavator.com/sites/ExProductPageMining/";       }
function ExProductPageMining_urlStart  	() {   return "examples.netscavator.com/sites/ExProductPageMining/dosearch.php";    }

function ExProductPageMining_beginMining()         
{
    // --- Dom sequences for the DoSearch (DS) page ---
    domSeqCreate  ( "DoSearchBtn_FIND_DS"    , "INPUT, value, Search"        , "equals"         );
    domSeqCreate  ( "ClothesSelect_FIND_DS"  , "SELECT, name, clothes_type"  , "equals"         );
    domSeqCreate  ( "FabricSelect_FIND_DS"   , "SELECT, name, fabric_type"   , "equals"         );

    // --- Dom sequences for the SearchListing (SL) page ---
    domSeqCreate  ( "ProductStart_FIND_SL"   , "DIV, class, product"         , "equals"         );
    domSeqCreate  ( "ProductUrl_FIND_SL"     , "A, href, productPage.php"    , "contains"       );
    domSeqCreate  ( "DoClickNext_FIND_SL"    , "Next, /A"                    , "contains", -2   );

    // --- Dom sequences for the ProductPage (PP) page ---
    domSeqCreate  ( "ProductName_FIND_PP"    , "TD, Type:, /TD, TD"           , "contains", 1   );  
    domSeqCreate  ( "ProductPrice_FIND_PP"   , "TD, Price:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductColor_FIND_PP"   , "TD, Color:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductFabric_FIND_PP"  , "TD, Fabric, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductBrand_FIND_PP"   , "TD, Brand:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductId_FIND_PP"      , "TD, Product ID:, /TD, TD"     , "contains", 1   );  
    domSeqCreate  ( "ProductSex_FIND_PP"     , ""                             , "contains"      );  // Empty sequence means we do not want it to ever match/find it

    
    // Navigator
    navDropDownSelectCreate("clothesSelect");
    navAttributeNamesCreate ("product_name, sex");
    navOptionAdd ( 1,  "dresses"        , ATTR, "Dress,  F"  );
    navOptionAdd ( 2,  "ties"           , ATTR, "Tie,    M"  );
    navOptionAdd ( 3,  "jackets"        , ATTR, "Jacket, MF" );
    navDropDownSelectCreate("fabricSelect");
    navAttributeNamesCreate ("fabric");
    navOptionAdd ( 1,  "wool"           , ATTR, "Wool"       );
    navOptionAdd ( 2,  "cotton"         , ATTR, "Cotton"     );
    //dbgPrintNavigatorStates(10); // Comment in to print the states. Parameter is specifying how many states to print at most. 
}


// ------------------------------------
// --- DoSearch (DS) page functions ---
// ------------------------------------
function ExProductPageMining_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function ExProductPageMining_DoSearch_mine()            
{
    // Nothing to mine on the "do search" page
}


function ExProductPageMining_DoSearch_navigate()           
{   
    doActionFind ( 1, "ClothesSelect_FIND_DS",   "clothesSelect" ); // Select clothes drop down according to current navigator state
    doActionFind ( 1, "FabricSelect_FIND_DS",    "fabricSelect"  ); // Select fabric drop down according to current navigator state
    doActionFind ( 1, "DoSearchBtn_FIND_DS",     "click" );         // Click on search button.
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// -------------------------------------
// --- Search listing (SL) functions ---
// -------------------------------------
function ExProductPageMining_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function ExProductPageMining_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStart_FIND_SL" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStart_FIND_SL" );
        domSetStopPos( $iStopPos );
        GetProduct_SL();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct_SL()            
{
    // All we need to do here is to put the (full) URL of each element in the urlQueue.
    // Since each URL is only relative to the current site we prepend urlSite()
    if ( domFindNext ( 1, "ProductUrl_FIND_SL" ) ) {
        urlQueueAppendUnique( urlSite() . valueGet() );
        //printf("DBG: urlSite() . valueGet(): %s\n", urlSite() . valueGet()  );
    }
}

function ExProductPageMining_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNext_FIND_SL" ) ) {
        nodeClick();
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else if ( urlQueueSize() > 0 ) {
        return false;       // Start to emty the queue
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad ( "examples.netscavator.com/sites/ExProductPageMining/dosearch.php" );  // Back to search page
            return true;
        }
        return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}


// ----------------------------------
// --- ProductPage (PP) functions ---
// ----------------------------------
function ExProductPageMining_ProductPage_match()          
{   
    return contains_fn( urlCurrent() , "productPage.php" );  // Handle any page with 'productPage.php' in the URL.
}

function ExProductPageMining_ProductPage_mine()            
{
    domNewSearch();
    // Get product details
    contextBegin("product");
    outputDirect( "product_url" , urlCurrent() );
    outputValueFindNext( 1, "ProductName_FIND_PP"   , "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPrice_FIND_PP"  , "product_price", "trimNumber" );
    outputValueFindNext( 1, "ProductColor_FIND_PP"  , "color"  );
    outputValueFindNext( 1, "ProductFabric_FIND_PP" , "fabric" );  
    outputValueFindNext( 1, "ProductBrand_FIND_PP"  , "brand_name" );  
    outputValueFindNext( 1, "ProductId_FIND_PP"     , "product_id" );  
    outputValueFindNext( 1, "ProductSex_FIND_PP"    , "sex" );   // Get value from Navigator attribute by fallback on fail to find dom pos
    outputDirect ( "currency_name" , "EUR" );  
    outputDirect ( "navigator_state", navStateString() );   // Write the navigator state for demo/debug
    contextEnd();
}

function ExProductPageMining_ProductPage_navigate()           
{   
    if ( urlQueueSize() > 0 ) {
        return false;   // Process next ProductPage in queue
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad ( "examples.netscavator.com/sites/ExProductPageMining/dosearch.php" );  // Back to search page
            return true;
        }
    }
    return false;
}

?>

