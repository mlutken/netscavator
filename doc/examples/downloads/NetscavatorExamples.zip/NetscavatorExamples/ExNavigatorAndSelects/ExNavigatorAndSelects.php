<?php
require_once "webminer.php";
 
// ---------------------------------------
// --- Global configuration ---
// --------------------------------------- 
function Script_minerName					() { return "ExNavigatorAndSelects"; }
function ExNavigatorAndSelects_urlSite   	() { return "examples.netscavator.com/sites/ExNavigatorAndSelects/index.php";       }
function ExNavigatorAndSelects_urlStart  	() { return "examples.netscavator.com/sites/ExNavigatorAndSelects/dosearch.php";    }


function ExNavigatorAndSelects_beginMining()         
{
   // Define dom sequences for the positions we need
    domSeqCreate  ( "DoSearchBtnSeq"    , "INPUT, value, Search"   , "equals"   );
    domSeqCreate  ( "ProductStartSeq"   , "DIV, class, product"    , "equals"   );
    domSeqCreate  ( "ProductNameSeq"    , ""                       , "equals"   ); // Empty means never find => fallback to navigator attribute   
    domSeqCreate  ( "ProductPriceSeq"   , "EUR"                    , "contains" );
    
    domSeqCreate  ( "DoClickNextSeq"    , "Next, /A"                , "contains", -2    );
    // (NOTE: we step back so we are sure to be within the A tag when we 'click' on the link.)

    domSeqCreate  ( "ClothesSelectSeq"  	, "SELECT, name, clothes_type"  , "equals" 	);
    domSeqCreate  ( "FabricSelectSeq"   	, "SELECT, name, fabric_type"   	, "equals"     );
    
    
    
    // Navigator
    navDropDownSelectCreate("clothesSelect");
    navAttributeNamesCreate ("product_name, sex");
    navOptionAdd ( 1,  "dresses"        	, ATTR, "Dress,  F"  	);
    navOptionAdd ( 2,  "ties"           	, ATTR, "Tie,    M"  	);
    navOptionAdd ( 3,  "jackets"        	, ATTR, "Jacket, MF" 	);
    navDropDownSelectCreate("fabricSelect");
    navAttributeNamesCreate ("fabric");
    navOptionAdd ( 1,  "wool"           	, ATTR, "Wool"       	);
    navOptionAdd ( 2,  "cotton"         	, ATTR, "Cotton"     	);
    //dbgPrintNavigatorStates(10); // Comment in to print the states. Parameter is specifying how many states to print at most. 

    // --- Notes on variations to play around with ---
    // ProductNameSeq: If you use the first one (same as example 3) we get the product name from the actual 
    //                 page we are mining which in these pages are with lowercase starting letter.
    //                 If you use the other version ("" - empty-string) the domFindNext part of the 
    //                 outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" ); will 
    //                 never find the sequence since the string empty-string are not present on the 
    //                 webpage. This results in the outputValue part of the outputValueFindNext function 
    //                 to look elswhere for a value for the 'product_name' which it is trying to write to the 
    //                 output. Since the navigator has an attribute defined called 'product_name' it then 
    //                 uses the current value of that attribute to write to the output. Since this attribute 
    //                 value changes along with the navigator changing states we now get the product names
    //                 with uppercase starting letters as we wrote them in the attributes for each option 
    //                 in the 'clothesSelect' of the navigator. 
    //                 See also in GetProduct() function : outputValueFindNext( 1, "", "sex" );
    //                 
}


// -------------------------------
// --- DoSearch page functions ---
// -------------------------------
function ExNavigatorAndSelects_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function ExNavigatorAndSelects_DoSearch_mine()            
{
    // Nothing to mine on the "do search" page
}


function ExNavigatorAndSelects_DoSearch_navigate()           
{   
    doActionFind ( 1, "ClothesSelectSeq",   "clothesSelect" ); // Select clothes drop down according to current navigator state
    doActionFind ( 1, "FabricSelectSeq",    "fabricSelect"  ); // Select fabric drop down according to current navigator state
    doActionFind ( 1, "DoSearchBtnSeq",     "click" );         // Click on search button.
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// --------------------------------
// --- Search listing functions ---
// --------------------------------
function ExNavigatorAndSelects_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function ExNavigatorAndSelects_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStartSeq" );
        domSetStopPos( $iStopPos );
        GetProduct();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct()            
{
   // Get product name and  product price
    contextBegin("product");
    outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" ); // Get value from Navigator attribute by fallback on fail to find dom pos
    outputValueFindNext( 1, "ProductPriceSeq", "product_price", "trimNumber" );
    outputValueFindNext( 1, "", "sex" );   // Get value from Navigator attribute by fallback on fail to find dom pos
    outputDirect ( "fabric" , navAttributeGet("fabric") );  // Gettting the attribute value directly  
    outputDirect ( "currency_name" , "EUR" );  
    outputDirect ( "navigator_state", navStateString() );   // Write the navigator state for demo/debug
    outputDirect ( "nav_state_indices", navCurrentStateIndicesGet() );   // Write the navigator state indices for demo/debug
    outputDirect ( "dbg_state_progress", (string)navLastStateIndexGet() . " / " . navStateIndexGet() ); 
    contextEnd();
}

function ExNavigatorAndSelects_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNextSeq" ) ) {
        nodeClick();
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad ( "examples.netscavator.com/sites/ExNavigatorAndSelects/dosearch.php" );  // Back to search page
            return true;
        }
        return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}

?>

