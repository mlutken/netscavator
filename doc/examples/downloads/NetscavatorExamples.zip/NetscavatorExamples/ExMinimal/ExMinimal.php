<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------

function Script_minerName   () {   return "ExMinimal";       }

function ExMinimal_urlSite  () {   return "examples.netscavator.com/sites/ExMinimal";   }

// ----------------------------------
// --- DoSearch handler functions ---
// ----------------------------------
function ExMinimal_DoSearch_match()          
{   
    return true;    // When we only mine a single page, simply say that any page matches.
}

function ExMinimal_DoSearch_mine()           
{
    printf("ExMinimal_DoSearch_mine()\n");
    outputDirect("item_name", "item_value");
}

function ExMinimal_DoSearch_navigate()           
{   
    printf("ExMinimal_DoSearch_navigate()\n");
    return false;    
}

?>

