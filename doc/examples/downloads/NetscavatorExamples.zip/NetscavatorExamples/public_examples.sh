#!/bin/bash
# Set examples here to use public webserver (examples.netscavator.com)

./subst.pl sleipnerexamples.com.localhost examples.netscavator.com \*.php .


