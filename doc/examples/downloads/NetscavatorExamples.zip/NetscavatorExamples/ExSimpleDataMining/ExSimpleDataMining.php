<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName           () {   return "ExSimpleDataMining";       }

function ExSimpleDataMining_urlSite () {   return "examples.netscavator.com/sites/ExSimpleDataMining";   }


// --------------------------------
// --- Search listing functions ---
// --------------------------------
function ExSimpleDataMining_SearchListing_match()          
{   
    return true;    // When we only mine a single page simply say that any page is the correct one.
}

function ExSimpleDataMining_SearchListing_mine()           
{
    domNewSearch();     //Reset current dom position to first node

    // --- product_name ---
    domFindNext ( 1, "color:green", "contains" );
    domStep(1);                     // Goto actual name which is next position
    outputValue("product_name");
    
    // --- product_price ---
    domFindNext( 1, "EUR", "contains");
    outputValue("product_price");
}


function ExSimpleDataMining_SearchListing_navigate()           
{   
    return false;   
}

?>

