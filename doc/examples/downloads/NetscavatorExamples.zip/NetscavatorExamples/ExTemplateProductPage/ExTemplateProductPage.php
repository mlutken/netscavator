<?php
require_once "ExTemplateProductPage.tpl.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------

function Script_minerName                () { return "ExTemplateProductPage";       }
function ExTemplateProductPage_urlSite   () { return "examples.netscavator.com/sites/ExTemplateProductPage/";       }
function ExTemplateProductPage_urlStart  () { return "examples.netscavator.com/sites/ExTemplateProductPage/dosearch.php";    }

function ExTemplateProductPage_beginMining()         
{
    settingSet    ( "DoSearchUrl", "examples.netscavator.com/sites/ExTemplateProductPage/dosearch.php" ); 

    // --- Dom sequences for the DoSearch (DS) page ---
    domSeqCreate  ( "DoSearchBtn_FIND_DS"    , "INPUT, value, Search"        , "equals"          );
    domSeqCreate  ( "ClothesSelect_FIND_DS"  , "SELECT, name, clothes_type"  , "equals"          );
    domSeqCreate  ( "FabricSelect_FIND_DS"   , "SELECT, name, fabric_type"   , "equals"          );

    // --- Dom sequences for the SearchListing (SL) page ---
    domSeqCreate  ( "ProductStart_FIND_SL"   , "DIV, class, product"         , "equals"          );
    domSeqCreate  ( "ProductUrl_FIND_SL"     , "A, href, productPage.php"    , "contains"        );
    domSeqCreate  ( "DoClickNext_FIND_SL"    , "Next, /A"                    , "contains", -2    );

    // --- Dom sequences for the ProductPage (PP) page ---
    domSeqCreate  ( "ProductName_FIND_PP"    , "TD, Type:, /TD, TD"           , "contains", 1   );  
    domSeqCreate  ( "ProductPrice_FIND_PP"   , "TD, Price:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductColor_FIND_PP"   , "TD, Color:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductFabric_FIND_PP"  , "TD, Fabric, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductBrand_FIND_PP"   , "TD, Brand:, /TD, TD"          , "contains", 1   );  
    domSeqCreate  ( "ProductId_FIND_PP"      , "TD, Product ID:, /TD, TD"     , "contains", 1   );  
    domSeqCreate  ( "ProductSex_FIND_PP"     , ""                             , "contains"  );  
    
    // Navigator
    navDropDownSelectCreate("clothesSelect");
    navAttributeNamesCreate ("product_name, sex");
    navOptionAdd ( 1,  "dresses"        , ATTR, "Dress,  F"  );
    navOptionAdd ( 2,  "ties"           , ATTR, "Tie,    M"  );
    navOptionAdd ( 3,  "jackets"        , ATTR, "Jacket, MF" );
    navDropDownSelectCreate("fabricSelect");
    navAttributeNamesCreate ("fabric");
    navOptionAdd ( 1,  "wool"           , ATTR, "Wool"       );
    navOptionAdd ( 2,  "cotton"         , ATTR, "Cotton"     );
}


// -----------------------
// --- Match functions ---
// -----------------------
function ExTemplateProductPage_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function ExTemplateProductPage_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function ExTemplateProductPage_ProductPage_match()          
{   
    return contains_fn( urlCurrent() , "productPage.php" );  // Handle any page with 'productPage.php' in the URL.
}


?>

