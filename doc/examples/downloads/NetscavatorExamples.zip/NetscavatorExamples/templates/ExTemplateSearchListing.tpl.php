<?php
require_once "webminer.php";


function TEMPLATE_DoSearch_navigate()           
{   
    doActionFind ( 1, "ClothesSelectSeq",   "clothesSelect" ); // Select clothes drop down according to current navigator state
    doActionFind ( 1, "FabricSelectSeq",    "fabricSelect"  ); // Select fabric drop down according to current navigator state
    doActionFind ( 1, "DoSearchBtnSeq",     "click" );         // Click on search button.
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// --------------------------------
// --- Search listing functions ---
// --------------------------------
function TEMPLATE_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function TEMPLATE_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStartSeq" );
        domSetStopPos( $iStopPos );
        GetProduct();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct()            
{
    // Get product name and  product price
    contextBegin("product");
    outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPriceSeq", "product_price", "trimNumber" );
    outputValueFindNext( 1, "", "sex" );   // Get value from Navigator attribute by fallback on fail to find dom pos
    outputDirect ( "fabric" , navAttributeGet("fabric") );  // Gettting the attribute value directly  
    outputDirect ( "currency_name" , "EUR" );  
    outputDirect ( "navigator_state", navStateString() );   // Write the navigator state for demo/debug
    outputDirect ( "dbg_state_progress", (string)navNumStatesGet() . " / " . navStateIndexGet() ); 
    contextEnd();
}

function TEMPLATE_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNextSeq" ) ) {
        nodeClick();
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad( settingGet("DoSearchUrl") );
            return true;
        }
         return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}

?>

