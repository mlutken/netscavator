<?php
require_once "webminer.php";

// ------------------------------------
// --- DoSearch (DS) page functions ---
// ------------------------------------

function TEMPLATE_DoSearch_mine()            
{
}


function TEMPLATE_DoSearch_navigate()           
{   
    doActionFind ( 1, "ClothesSelect_FIND_DS",   "clothesSelect" ); // Select clothes drop down according to current navigator state
    doActionFind ( 1, "FabricSelect_FIND_DS",    "fabricSelect"  ); // Select fabric drop down according to current navigator state
    doActionFind ( 1, "DoSearchBtn_FIND_DS",     "click" );         // Click on search button.
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// -------------------------------------
// --- Search listing (SL) functions ---
// -------------------------------------
function TEMPLATE_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function TEMPLATE_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStart_FIND_SL" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStart_FIND_SL" );
        domSetStopPos( $iStopPos );
        GetProduct_SL();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct_SL()            
{
    // Since each URL is only relative to the current site we prepend urlSite()
    if ( domFindNext ( 1, "ProductUrl_FIND_SL" ) ) {
        urlQueueAppendUnique( urlSite() . valueGet() );
    }
}

function TEMPLATE_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNext_FIND_SL" ) ) {
        nodeClick();
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else if ( urlQueueSize() > 0 ) {
        return false;       // Start to emty the queue
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad( settingGet("DoSearchUrl") );
            return true;
        }
        return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}

// ----------------------------------
// --- ProductPage (PP) functions ---
// ----------------------------------

function TEMPLATE_ProductPage_mine()            
{
    domNewSearch();
    // Get product name and  product price
    contextBegin("product");
    outputDirect( "product_url" , urlCurrent() );
    outputValueFindNext( 1, "ProductName_FIND_PP"   , "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPrice_FIND_PP"  , "product_price", "trimNumber" );
    outputValueFindNext( 1, "ProductColor_FIND_PP"  , "color"  );
    outputValueFindNext( 1, "ProductFabric_FIND_PP" , "fabric" );  
    outputValueFindNext( 1, "ProductBrand_FIND_PP"  , "brand_name" );  
    outputValueFindNext( 1, "ProductId_FIND_PP"     , "product_id" );  
    outputValueFindNext( 1, "ProductSex_FIND_PP"    , "sex" );   // Get value from Navigator attribute by fallback on fail to find dom pos
    outputDirect ( "currency_name" , "EUR" );  
    outputDirect ( "navigator_state", navStateString() );   // Write the navigator state for demo/debug
    contextEnd();
}


function TEMPLATE_ProductPage_navigate()           
{   
    if ( urlQueueSize() > 0 ) {
        return false;   // Process next ProductPage in queue
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad( settingGet("DoSearchUrl") );
            return true;
        }
    }
    return false;
}

?>

