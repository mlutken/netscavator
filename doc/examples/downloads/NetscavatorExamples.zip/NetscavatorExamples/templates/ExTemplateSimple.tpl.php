<?php
require_once "webminer.php";


// Completely general way way of looping through a list of products
function TEMPLATE_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        $savePos = domGetPos(); // Save dom position
        $iStopPos = domFindNextPos( 1, "ProductStartSeq" );
        domSetStopPos( $iStopPos ); // Set stop position to start of next product block
        GetProduct();
        domClearStopPos();
        domSetPos($savePos);    // Restore position so we are ready to find next product start
    }
}

function GetProduct()            
{
    // Get product name and  product price
    contextBegin("product");
    outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPriceSeq", "product_price", "trimNumber" );
    outputDirect ( "currency_name" , "EUR" );  
    contextEnd();
}

function TEMPLATE_SearchListing_navigate()           
{   
    return false;   
}

?>

