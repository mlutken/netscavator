<?php
require_once "ExTemplateSearchListing.tpl.php";

// ----------------------------
// --- Global configuration ---
// ---------------------------- 
function Script_minerName                   () { return "ExTemplateSearchListing";       }
function ExTemplateSearchListing_urlSite  	() { return "examples.netscavator.com/sites/ExTemplateSearchListing/index.php";       }
function ExTemplateSearchListing_urlStart   () { return "examples.netscavator.com/sites/ExTemplateSearchListing/dosearch.php";    }

function ExTemplateSearchListing_beginMining()         
{
    // Required: Set to URL of search page as the TEMPLATE_SearchListing_navigate() function needs it.
    settingSet    ( "DoSearchUrl", "examples.netscavator.com/sites/ExTemplateSearchListing/dosearch.php" ); 
    
    // Define dom sequences for the positions we need
    domSeqCreate  ( "DoSearchBtnSeq"    , "INPUT, value, Search"    , "equals"       );
    domSeqCreate  ( "ProductStartSeq"   , "DIV, class, product"     , "equals"       );
    domSeqCreate  ( "ProductNameSeq"    , ""                        , "equals"       );  // Empty => fallback to nav attribute
    domSeqCreate  ( "ProductPriceSeq"   , "EUR"                     , "contains"     );
    domSeqCreate  ( "DoClickNextSeq"    , "Next, /A"                , "contains", -2 );
    // (NOTE: we step back so we are sure to be within the A tag when we 'click' on the link.)

    domSeqCreate  ( "ClothesSelectSeq"  	, "SELECT, name, clothes_type"  , "equals"  );
    domSeqCreate  ( "FabricSelectSeq"   	, "SELECT, name, fabric_type"   , "equals"  );
     
    // Navigator
    navDropDownSelectCreate("clothesSelect");
    navAttributeNamesCreate ("product_name, sex");
    navOptionAdd ( 1,  "dresses"        	, ATTR, "Dress,  F"  	);
    navOptionAdd ( 2,  "ties"           	, ATTR, "Tie,    M"  	);
    navOptionAdd ( 3,  "jackets"        	, ATTR, "Jacket, MF" 	);
    navDropDownSelectCreate("fabricSelect");
    navAttributeNamesCreate ("fabric");
    navOptionAdd ( 1,  "wool"           	, ATTR, "Wool"       	);
    navOptionAdd ( 2,  "cotton"         	, ATTR, "Cotton"     	);
}


// -----------------------
// --- Match functions ---
// -----------------------
function ExTemplateSearchListing_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function ExTemplateSearchListing_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}


?>

