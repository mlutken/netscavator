<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName           () {   return "ExTypicalDataMining";       }
function ExTypicalDataMining_urlSite() {   return "examples.netscavator.com/sites/ExTypicalDataMining";   }

function ExTypicalDataMining_beginMining()         
{
    // Define dom sequences for the positions we need
    domSeqCreate  ( "ProductStartSeq"   , "DIV, class, product" , "equals"      );
    domSeqCreate  ( "ProductNameSeq"    , "color:green"         , "contains", 1 );
    domSeqCreate  ( "ProductPriceSeq"   , "EUR"                 , "contains"    );
}

// --------------------------------
// --- Search listing functions ---
// --------------------------------
function ExTypicalDataMining_SearchListing_match()          
{   
    return true;  // When we only mine a single page simply say that any page is the correct one.
}

// Completely general/reuseable way of looping through a list of products
function ExTypicalDataMining_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        $savePos = domGetPos(); // Save dom position
        $iStopPos = domFindNextPos( 1, "ProductStartSeq" );
        domSetStopPos( $iStopPos ); // Set stop position to start of next product block
        GetProduct();
        domClearStopPos();
        domSetPos($savePos);    // Restore position so we are ready to find next product start
    }
}

function GetProduct()            
{
    // Get product name and  product price
    contextBegin("product");
    outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPriceSeq", "product_price", "trimNumber" );
    outputDirect ( "currency_name" , "EUR" );  
    contextEnd();
}

function ExTypicalDataMining_SearchListing_navigate()           
{   
    return false;   
}

?>

