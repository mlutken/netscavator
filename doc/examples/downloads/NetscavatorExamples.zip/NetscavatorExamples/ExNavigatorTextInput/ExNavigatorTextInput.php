<?php
require_once "webminer.php";

// ----------------------------
// --- Global configuration ---
// ----------------------------
function Script_minerName               () { return "ExNavigatorTextInput"; }
function ExNavigatorTextInput_urlSite   () { return "examples.netscavator.com/sites/ExNavigatorTextInput/index.php";       }
function ExNavigatorTextInput_urlStart  () { return "examples.netscavator.com/sites/ExNavigatorTextInput/dosearch.php";    }

function ExNavigatorTextInput_beginMining()         
{
    // Define dom sequences for the positions we need
    domSeqCreate  ( "DoSearchBtnSeq"    , "INPUT, value, Search"        , "equals"          );
    domSeqCreate  ( "ProductStartSeq"   , "DIV, class, product"         , "equals"          );
    domSeqCreate  ( "ProductNameSeq"    , "color:green"                 , "contains", 1     ); // Note: Not empty string as in some previous examples
    domSeqCreate  ( "FabricTypeSeq"     , "color:black"                 , "contains", 1     );
    domSeqCreate  ( "ProductPriceSeq"   , "EUR"                         , "contains"        );
    
    domSeqCreate  ( "DoClickNextSeq"    , "Next, /A"                    , "contains", -2    );
    // (NOTE: we step back so we are sure to be within the A tag when we 'click' on the link.)

    domSeqCreate  ( "ClothesSelectSeq"  , "INPUT, name, clothes_type"  , "equals"          );
    
    // Navigator
    navInputOptionsCreate( "clothesSelect" );
    navAttributeNamesCreate ("sex");
    navOptionAdd ( "dress"        , ATTR, "F"  );
    navOptionAdd ( "tie"          , ATTR, "M"  );
    navOptionAdd ( "jacket"       , ATTR, "MF" );
}

/* 
Custom filter function. Note that when using a manipulator like eraseAll as 
a plain php function and not within the outputValueFindNext and similar 
functions we need to use the versions wich ends with '_fn' and write the 
name without quotes like any other function like for example 
eraseAll_fn(...) as opposed to "eraseAll". 
*/
function filterFabricType($val)
{
    $val = eraseAll_fn($val, "(" ); 
    $val = eraseAll_fn($val, ")" );
    return $val;
}


// -------------------------------
// --- DoSearch page functions ---
// -------------------------------
function ExNavigatorTextInput_DoSearch_match()          
{   
    return contains_fn( urlCurrent() , "dosearch.php" );  // Handle do search page.
}

function ExNavigatorTextInput_DoSearch_mine()            
{
    // Nothing to mine on the "do search" page
}


function ExNavigatorTextInput_DoSearch_navigate()           
{   
    doActionFind ( 1, "ClothesSelectSeq",   "clothesSelect" ); // Input search string according to current navigator state
    doActionFind ( 1, "DoSearchBtnSeq",     "click" );         // Click on search button.
    return true;  // Return 'true' since the navigation results in loading of a new page.
}


// --------------------------------
// --- Search listing functions ---
// --------------------------------
function ExNavigatorTextInput_SearchListing_match()          
{   
    return contains_fn( urlCurrent() , "searchlisting" );  // Handle any page with 'searchlisting' in the URL.
}

function ExNavigatorTextInput_SearchListing_mine()            
{
    domNewSearch();
    while ( domFindNext ( 1, "ProductStartSeq" ) ) {
        domPointerPush();
        $iStopPos = domFindNextPos( 1, "ProductStartSeq" );
        domSetStopPos( $iStopPos );
        GetProduct();
        domClearStopPos();
        domPointerPop();
    }
}

function GetProduct()            
{
    // Get product name and  product price
    contextBegin("product");
    outputValueFindNext( 1, "ProductNameSeq", "product_name", "eraseAll", ":" );
    outputValueFindNext( 1, "ProductPriceSeq", "product_price", "trimNumber" );
    outputValueFindNext( 1, "FabricTypeSeq", "fabric", "filterFabricType" );
    outputValueFindNext( 1, "", "sex" );   // Get value from Navigator attribute by fallback on fail to find dom pos
    outputDirect ( "currency_name" , "EUR" );  
    outputDirect ( "navigator_state", navStateString() );   // Write the navigator state for demo/debug
    contextEnd();
}

function ExNavigatorTextInput_SearchListing_navigate()           
{   
    if ( domFind ( 1, "DoClickNextSeq" ) ) {
        nodeClick();
        return true;    // if we find a 'next' link then a new page will be loaded
    }
    else {
        if ( !navNavigationDone() ) {
            navNextState(); // Go to next state in navigator
            urlLoad ( "examples.netscavator.com/sites/ExNavigatorTextInput/dosearch.php" );  // Back to search page
            return true;
        }
        return false;   // No 'next' link, no new page will be loaded. Miner closes down.  
    }
}

?>

