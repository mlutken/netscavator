<?php
require_once "webminer.php";
require_once "thehive.movies.tpl.php";
// VERIFIED: 14/11-2013

TEMPLATE__parseCommandLine ( "" );  // Required: Additional command line parameter can be specified if needed, like shown in example


// ----------------------------
// --- Global configuration ---
// ----------------------------
function Crawler__outputName    () { return "mysite.com";  }
function Crawler__urlSite       () { return "http://www.mysite.com"; }    // Required: Set to site URL like 'http://www.ginza.se'
function Crawler__urlStart      () { return "http://www.mysite.com"; }    // Optional: Set to start up URL if different from urlSite.

// Do site specific configuration
function Crawler__setRunConfig()         
{
    //configAddExcludeUrl ( "google-analytics.com",  "contains"    ); // EXAMPLE ONLY: this is set from template in 'robot runmode'. I.e. when using 'robot_runminer' 
}

// ------------------------------------------------------------------
// --- Match functions (must be implemented - and in shown order) ---
// ------------------------------------------------------------------

function Crawler__DoSearch__match()           
{   
  return equals_fn ( urlCurrent(), settingGet( "DoSearchUrl") );
}

function Crawler__SearchListing__match()          
{   
    return contains_fn ( urlCurrent(), "/label/" );
}

function Crawler__ProductPage__match()          
{   
    return contains_fn ( urlCurrent(), "/soundtrack/" );  
}


// -------------------------------------------------------------------------------------------
// --- PHP functions as replacement where dom sequences, modifies, actions are not enough  ---
// -------------------------------------------------------------------------------------------


// ---------------------------------------------------------------------------
// --- Site specific setup of settings, dom sequences,modifies and actions ---
// ---------------------------------------------------------------------------

function Crawler__doSetup()          
{
	outputDirect("hest", "Crawler__doSetup");
    dataPushContext ( "begin_mining_common" );
    outputDirect 	( "my_list", "item1"	);
    outputDirect 	( "my_other_list", "other_item1"	);
    outputDirect 	( "my_list", "item2"	);
    outputDirect 	( "my_other_list", "other_item2"	);
    outputDirect 	( "my_other_list", "other_item3", "prepend", "prepended__"	);
    outputDirect 	( "my_list", "item3", "prepend", "prepended__"	);
    dataPopContext  ();

	configParseDecimalPointSet( "." );
	//configParseThousandsSepSet( "," );
   // --- General settings ---
    settingSet   ( "scanMode", "full");              // Search listing pages does not have prices, so we ony support scanMode='full' here!
    settingSet   ( "HasScanModeFull", "true" );      // Semi Optional: Default is 'false', set to 'true' if scanMode 'full' (collect songs from product pages) is implemented )
    settingSet   ( "product_type", "music" );                         // Required: Set to correct index (product domain type like: music, movies, freezer, book, etc.)
    settingSet   ( "record_type", "price" );                         // Required: Set to correct type (like price, xxx, etc.)
    settingSet   ( "currency_name", "USD" );                         // Required: Set to currency used on site like DKK, SEK, GBP, EUR, USD, NOK etc.
    settingSet   ( "SearchStep1__URL", "http://www.moviemusic.com/search/movie-soundtrack-labels/" );                              // Required: Set to URL of search page

    // ----------------------------------------------
    // --- _DoSearch_ Dom sequences and modifiers ---
    // ----------------------------------------------
    domSeqCreate    ( "categoryNameSelect__FIND" , "BODY", "contains",0  );          // Optional: Fires action: 'category'
    domSeqCreate    ( "mediaFormatNameSelect__FIND", "BODY", "contains",0  );     // Optional: Fires action: 'media_format_name'
    domSeqCreate    ( "doSearch__FIND" , "BODY", "contains", 0 );                   // Required: Fires action 'doSearch'

    // ---------------------------------------------------
    // --- _SearchListing_ Dom sequences and modifiers ---
    // ---------------------------------------------------

    domSeqCreate    ( "itemStart__SearchListing__FIND"             , "BR, A, href", "contains", -2 ); // Required: Finds start of a search list item
    domSeqCreate    ( "buy_at_url__SearchListing__FIND"            , "A", "contains", 2 ); // Required: Finds URL of product page
    modifierCreate  ( "buy_at_url__SearchListing__MOD"             , "buy_at_url__SearchListing__MOD" );    
    domSeqCreate    ( "owner_name__SearchListing__FIND"           , "A, href, title", "contains", 0 ); // Required: Finds artist name  


    // -------------------------------------------------
    // --- _ProductPage_ Dom sequences and modifiers ---
    // -------------------------------------------------
    // --- main item (album/song) ---
    domSeqCreate    ( "image_url_1__ProductPage__FIND"         , "TD, class, left, IMG, src", "contains", 1 ); // Optional: Finds small cover image URL
    modifierCreate  ( "image_url_1__ProductPage__MOD"         , "prepend" , urlSite() );
	domSeqCreate  	( "owner_name__ProductPage__FIND#1"   , "/H1, ?, A, href", "contains", 2);
    domSeqCreate    ( "price_name__ProductPage__FIND"          , "TD, class, right, H1", "contains", 1 ); // Required: Finds item name
    domSeqCreate    ( "price_local__ProductPage__FIND"           , "New CD Price:", "contains", 6 ); // Required: Finds local price - need to be this tag - because of used items too.
	domSeqCreate	( "description__ProductPage__FIND", "/TBODY,/TABLE,/TD,TD, class", "equals", 0);

    // -----------------
    // --- Navigator ---
    // -----------------
    navUrlLoadCreate("categoryNameSelect", "http://www.moviemusic.com");
    navAttributeNamesCreate ("category, media_format_name, media_type_name, data_record_type");

    navOptionAdd    ( "Varese+Sarabande"                , "/label/L47/Varese+Sarabande/"                , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Milan"                      	, "/label/L3/Milan/"                            , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Lakeshore+Records"  		, "/label/L177/Lakeshore+Records/"              , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "FSM"                   		, "/label/L56/FSM/"                             , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Silva+Screen"                    , "/label/L25/Silva+Screen/"                    , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Intrada+Special+Collection"      , "/label/L193/Intrada+Special+Collection/"     , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Hollywood"                	, "/label/L38/Hollywood/"                       , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Warner+Bros"                	, "/label/L54/Warner+Bros/"                     , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "MCA"                     	, "/label/L40/MCA/"                             , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "RCA+Victor"	                , "/label/L5/RCA+Victor/"                       , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Disney"                		, "/label/L34/Disney/"                          , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Columbia"                	, "/label/L28/Columbia/"                        , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "La-La+Land"                	, "/label/L169/La-La+Land/"                     , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Varese+Sarabande+Club"           , "/label/L194/Varese+Sarabande+Club/"          , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Sony+Classical"                  , "/label/L30/Sony+Classical/"                  , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Rhino"                		, "/label/L52/Rhino/"                           , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Atlantic"                	, "/label/L51/Atlantic/"                        , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Intrada"                   	, "/label/L16/Intrada/"                         , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Capitol"                         , "/label/L11/Capitol/"                         , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "MovieScore+Media"                , "/label/L253/MovieScore+Media/"               , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Decca"                           , "/label/L79/Decca/"                           , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Epic+Soundtrax"                  , "/label/L29/Epic+Soundtrax/"                  , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Virgin"                          , "/label/L12/Virgin/"                          , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "GNP+Crescendo"                   , "/label/L15/GNP+Crescendo/"                   , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "TVT"                             , "/label/L32/TVT/"                             , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "drg"                             , "/label/L8/drg/"                              , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Sony"                            , "/label/L27/Sony/"                            , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Ryko"                            , "/label/L23/Ryko/"                            , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Silva+Screen+UK"                 , "/label/L196/Silva+Screen+UK/"                , ATTR, "Soundtracks, CD, audio, album"  );
    navOptionAdd    ( "Mercury"                         , "/label/L49/Mercury/"                         , ATTR, "Soundtracks, CD, audio, album"  );

    // Set start,end states according to main navUrlLoad
    $start  = cmdValStrGet("start");
    $end    = cmdValStrGet("end");  
    navBeginStateSet("${start}"   );  
    navEndStateSet  ("${end}"     );  

}

// ----------------------
// --- Work functions ---
// ----------------------

function Crawler__beginMining()          
{
    outputHeader( "MovieMusic (US)", "USA" );  // Required: Set shop name, country name: 'Denmark', 'Sweden', 'Norway', 'Germany', 'UK', 'USA' ...
}

function Crawler__endMining()            
{   
}

?>
